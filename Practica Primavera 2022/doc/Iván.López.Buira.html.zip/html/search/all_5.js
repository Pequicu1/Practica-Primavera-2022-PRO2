var searchData=
[
  ['jugador_0',['Jugador',['../class_jugador.html',1,'Jugador'],['../class_jugador.html#a232c46f75691af6210096e5972535d71',1,'Jugador::Jugador()']]],
  ['jugador_2ehh_1',['Jugador.hh',['../_jugador_8hh.html',1,'']]]
];
