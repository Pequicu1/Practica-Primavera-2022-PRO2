var searchData=
[
  ['tabla_5fde_5fpuntuaciones_0',['Tabla_de_puntuaciones',['../class_cjt___torneos.html#a03d189bf6edfa8e33e71a9757f34c657',1,'Cjt_Torneos']]],
  ['torneo_1',['Torneo',['../class_torneo.html',1,'Torneo'],['../class_torneo.html#a7bf6d35a7ec8d0e13a0bed8deb8add3e',1,'Torneo::Torneo()']]],
  ['torneo_2ehh_2',['Torneo.hh',['../_torneo_8hh.html',1,'']]]
];
