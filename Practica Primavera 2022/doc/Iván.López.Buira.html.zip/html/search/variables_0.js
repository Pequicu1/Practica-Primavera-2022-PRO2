var searchData=
[
  ['categoria_0',['categoria',['../class_torneo.html#ad9bec7ef311a416138abb99f3a487b3e',1,'Torneo']]],
  ['categorias_1',['categorias',['../class_cjt___torneos.html#ac022fbba080883fbc2763260b07853d5',1,'Cjt_Torneos']]],
  ['circuito_2',['circuito',['../class_cjt___torneos.html#a6495300a4ac9d99d6a5a13e0af4815d0',1,'Cjt_Torneos']]],
  ['cuadro_3',['Cuadro',['../class_torneo.html#a80d5c284797d185833a3ac90a0427acf',1,'Torneo']]]
];
