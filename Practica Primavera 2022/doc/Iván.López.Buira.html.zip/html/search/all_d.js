var searchData=
[
  ['value_0',['value',['../class_bin_tree.html#aaccb0c5b6cfe3b84dfeefc58efa24cda',1,'BinTree']]],
  ['vjug_1',['vjug',['../class_cjt___jugadores.html#a7c4e0b47e8a197b0b73ef5f008b58105',1,'Cjt_Jugadores']]]
];
