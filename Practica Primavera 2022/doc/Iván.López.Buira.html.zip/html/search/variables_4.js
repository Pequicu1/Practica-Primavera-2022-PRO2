var searchData=
[
  ['njug_0',['njug',['../class_cjt___jugadores.html#adad1113baffd28b8399ccde31d03d8d3',1,'Cjt_Jugadores']]],
  ['ntorn_1',['ntorn',['../class_cjt___torneos.html#a6700b36fda89f219b68f29a46a4df487',1,'Cjt_Torneos']]]
];
