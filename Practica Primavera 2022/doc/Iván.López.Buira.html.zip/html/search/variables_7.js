var searchData=
[
  ['tabla_5fde_5fpuntuaciones_0',['Tabla_de_puntuaciones',['../class_cjt___torneos.html#a03d189bf6edfa8e33e71a9757f34c657',1,'Cjt_Torneos']]]
];
