var searchData=
[
  ['_7ecjt_5fjugadores_0',['~Cjt_Jugadores',['../class_cjt___jugadores.html#a3a8ae0790c5429c87708051591cc865d',1,'Cjt_Jugadores']]],
  ['_7ecjt_5ftorneos_1',['~Cjt_Torneos',['../class_cjt___torneos.html#ad8cc56636ad7cba06542b88ecc6a20f7',1,'Cjt_Torneos']]],
  ['_7etorneo_2',['~Torneo',['../class_torneo.html#af733d8f40440880674a88c8918baf19c',1,'Torneo']]]
];
