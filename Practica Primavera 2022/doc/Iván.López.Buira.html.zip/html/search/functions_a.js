var searchData=
[
  ['pro2excepcio_0',['PRO2Excepcio',['../class_p_r_o2_excepcio.html#ac86c0800bbe57a3376f18a3ad6ea3c02',1,'PRO2Excepcio']]]
];
