var searchData=
[
  ['vjug_0',['vjug',['../class_cjt___jugadores.html#a7c4e0b47e8a197b0b73ef5f008b58105',1,'Cjt_Jugadores']]]
];
