var searchData=
[
  ['id_0',['id',['../class_jugador.html#aaeeacd8da7dd5926ca44073124b5fd71',1,'Jugador']]],
  ['identificador_1',['identificador',['../class_torneo.html#a8ef1999f3378e2b929bb042ddb98339d',1,'Torneo']]]
];
