var searchData=
[
  ['main_0',['main',['../main_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main.cc']]],
  ['modificar_5franking_1',['modificar_ranking',['../class_jugador.html#af7b4bdbeae795163b53d5f0b9445b766',1,'Jugador']]]
];
