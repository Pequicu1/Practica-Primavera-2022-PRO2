var searchData=
[
  ['anadir_5fjugador_0',['anadir_jugador',['../class_cjt___jugadores.html#a149d4ff7bae45574d668f045731bfaff',1,'Cjt_Jugadores']]],
  ['anadir_5ftorneo_1',['anadir_Torneo',['../class_cjt___torneos.html#a3111bef72d409401941fdb1f9173a1db',1,'Cjt_Torneos']]]
];
