var searchData=
[
  ['id_0',['id',['../class_jugador.html#aaeeacd8da7dd5926ca44073124b5fd71',1,'Jugador']]],
  ['identificador_1',['identificador',['../class_torneo.html#a8ef1999f3378e2b929bb042ddb98339d',1,'Torneo']]],
  ['imprimir_5fcuadro_2',['imprimir_cuadro',['../class_torneo.html#a9334e3b5e0eb8893adea650d63723508',1,'Torneo']]],
  ['imprimir_5fjugadores_3',['imprimir_jugadores',['../class_cjt___jugadores.html#abf5308b5d4ff571486fbd02e81bc6413',1,'Cjt_Jugadores']]],
  ['imprimir_5fresultados_4',['imprimir_resultados',['../class_torneo.html#ac80854695ac7fe36a1d9af2a3682257d',1,'Torneo']]],
  ['imprimir_5ftorneos_5',['imprimir_torneos',['../class_cjt___torneos.html#a3479fb8622fbc711fed12727780e8141',1,'Cjt_Torneos']]],
  ['ini_5fjugadores_6',['ini_jugadores',['../class_cjt___jugadores.html#a426c7e20ede71fd9fcbe34a1619d3e14',1,'Cjt_Jugadores']]],
  ['ini_5ftorneos_7',['ini_torneos',['../class_cjt___torneos.html#aecc09066184bd9773436f123a210b1f9',1,'Cjt_Torneos']]]
];
