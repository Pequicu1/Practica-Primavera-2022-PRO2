var searchData=
[
  ['categoria_0',['categoria',['../class_torneo.html#ad9bec7ef311a416138abb99f3a487b3e',1,'Torneo']]],
  ['categorias_1',['categorias',['../class_cjt___torneos.html#ac022fbba080883fbc2763260b07853d5',1,'Cjt_Torneos']]],
  ['circuito_2',['circuito',['../class_cjt___torneos.html#a6495300a4ac9d99d6a5a13e0af4815d0',1,'Cjt_Torneos']]],
  ['circuito_20de_20torneos_20de_20tenis_20_2d_20_5bpráctica_20primavera_202022_5d_2e_3',['CIRCUITO DE TORNEOS DE TENIS - [Práctica primavera 2022].',['../index.html',1,'']]],
  ['cjt_5fjugadores_4',['Cjt_Jugadores',['../class_cjt___jugadores.html',1,'Cjt_Jugadores'],['../class_cjt___jugadores.html#a2e7a3bb35253088c8b66d6cfbc89742f',1,'Cjt_Jugadores::Cjt_Jugadores()']]],
  ['cjt_5fjugadores_2ehh_5',['Cjt_Jugadores.hh',['../_cjt___jugadores_8hh.html',1,'']]],
  ['cjt_5ftorneos_6',['Cjt_Torneos',['../class_cjt___torneos.html',1,'Cjt_Torneos'],['../class_cjt___torneos.html#a3da93ce7730f6472ab958496f4af3ec1',1,'Cjt_Torneos::Cjt_Torneos()']]],
  ['cjt_5ftorneos_2ehh_7',['Cjt_Torneos.hh',['../_cjt___torneos_8hh.html',1,'']]],
  ['consultar_5fcategoria_8',['consultar_categoria',['../class_torneo.html#ac558198d579c88ab11b873ed3cf0953d',1,'Torneo']]],
  ['consultar_5fid_9',['consultar_id',['../class_jugador.html#a51e052535daea3c7d4354f794ef30738',1,'Jugador']]],
  ['consultar_5fpos_5franking_10',['consultar_pos_ranking',['../class_jugador.html#acfac089f0431e0d552c1af3b0d4c2213',1,'Jugador']]],
  ['consultar_5fpuntos_11',['consultar_puntos',['../class_jugador.html#a472bb412a7ae132929c7c023319fc829',1,'Jugador']]],
  ['crear_5ftorneo_12',['crear_torneo',['../class_torneo.html#afe86548b15f0df9121d413b9e5893132',1,'Torneo']]],
  ['cuadro_13',['Cuadro',['../class_torneo.html#a80d5c284797d185833a3ac90a0427acf',1,'Torneo']]]
];
