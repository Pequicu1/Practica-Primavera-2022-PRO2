var searchData=
[
  ['obtener_5fcuadro_0',['obtener_cuadro',['../class_torneo.html#a10549ccc617469d4de3c6a62ca91b42f',1,'Torneo']]],
  ['obtener_5fjugador_1',['obtener_jugador',['../class_cjt___jugadores.html#a2b4c5da18ea6eb38d3e97c8ff54dda59',1,'Cjt_Jugadores']]],
  ['obtener_5fpuntuacion_2',['obtener_puntuacion',['../class_cjt___torneos.html#a2de8584ec3b82801e26af94d47d85387',1,'Cjt_Torneos']]],
  ['obtener_5ftorneo_3',['obtener_torneo',['../class_cjt___torneos.html#a72f4b6af379241ca7408ca69a4651271',1,'Cjt_Torneos']]]
];
