var searchData=
[
  ['what_0',['what',['../class_p_r_o2_excepcio.html#a6627ed19302010f7b80f638592cce85b',1,'PRO2Excepcio']]]
];
