var searchData=
[
  ['njug_0',['njug',['../class_cjt___jugadores.html#adad1113baffd28b8399ccde31d03d8d3',1,'Cjt_Jugadores']]],
  ['node_1',['Node',['../struct_bin_tree_1_1_node.html',1,'BinTree&lt; T &gt;::Node'],['../struct_bin_tree_1_1_node.html#af45885e303875c018e89fa5c8b96bde0',1,'BinTree::Node::Node()']]],
  ['ntorn_2',['ntorn',['../class_cjt___torneos.html#a6700b36fda89f219b68f29a46a4df487',1,'Cjt_Torneos']]],
  ['numero_5fjugadores_3',['numero_jugadores',['../class_cjt___jugadores.html#ac0a8e34bec7aa6ef3ba33e6bb9eeaeb3',1,'Cjt_Jugadores']]],
  ['numero_5ftorneos_4',['numero_torneos',['../class_cjt___torneos.html#a0d18a560f7a69f89144c2eb2344d997e',1,'Cjt_Torneos']]]
];
