var searchData=
[
  ['cjt_5fjugadores_0',['Cjt_Jugadores',['../class_cjt___jugadores.html#a2e7a3bb35253088c8b66d6cfbc89742f',1,'Cjt_Jugadores']]],
  ['cjt_5ftorneos_1',['Cjt_Torneos',['../class_cjt___torneos.html#a3da93ce7730f6472ab958496f4af3ec1',1,'Cjt_Torneos']]],
  ['consultar_5fcategoria_2',['consultar_categoria',['../class_torneo.html#ac558198d579c88ab11b873ed3cf0953d',1,'Torneo']]],
  ['consultar_5fid_3',['consultar_id',['../class_jugador.html#a51e052535daea3c7d4354f794ef30738',1,'Jugador']]],
  ['consultar_5fpos_5franking_4',['consultar_pos_ranking',['../class_jugador.html#acfac089f0431e0d552c1af3b0d4c2213',1,'Jugador']]],
  ['consultar_5fpuntos_5',['consultar_puntos',['../class_jugador.html#a472bb412a7ae132929c7c023319fc829',1,'Jugador']]],
  ['crear_5ftorneo_6',['crear_torneo',['../class_torneo.html#afe86548b15f0df9121d413b9e5893132',1,'Torneo']]]
];
