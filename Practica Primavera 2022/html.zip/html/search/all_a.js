var searchData=
[
  ['obtener_5fcuadro_0',['obtener_cuadro',['../class_torneo.html#aed1241440a947e4dd71a0a3c97481975',1,'Torneo']]],
  ['obtener_5fjugador_1',['obtener_jugador',['../class_cjt___jugadores.html#a2b4c5da18ea6eb38d3e97c8ff54dda59',1,'Cjt_Jugadores']]],
  ['obtener_5fparticipantes_2',['obtener_participantes',['../class_torneo.html#acdaa34d23dbd73346e5e23a238a6802e',1,'Torneo']]],
  ['obtener_5fpuntuaciones_3',['obtener_puntuaciones',['../class_cjt___torneos.html#ab57a49674be1f0f72f01ff1f644d166e',1,'Cjt_Torneos']]],
  ['obtener_5franking_4',['obtener_ranking',['../class_cjt___jugadores.html#a7fa4336496793fac97563dfa93b84eac',1,'Cjt_Jugadores']]],
  ['obtener_5ftorneo_5',['obtener_torneo',['../class_cjt___torneos.html#a72f4b6af379241ca7408ca69a4651271',1,'Cjt_Torneos']]],
  ['ordenar_5franking_6',['ordenar_ranking',['../class_cjt___jugadores.html#aa3e654d501a23e4f43a1a61cdf7507cc',1,'Cjt_Jugadores']]]
];
