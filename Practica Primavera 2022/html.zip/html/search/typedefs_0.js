var searchData=
[
  ['matriz_0',['Matriz',['../_cjt___torneos_8hh.html#a542f05eb5259f8e5499aa2e207ddffc3',1,'Cjt_Torneos.hh']]]
];
