var searchData=
[
  ['id_0',['id',['../class_jugador.html#aaeeacd8da7dd5926ca44073124b5fd71',1,'Jugador']]],
  ['identificador_1',['identificador',['../class_torneo.html#a8ef1999f3378e2b929bb042ddb98339d',1,'Torneo']]],
  ['indice_5fjugadores_2',['indice_jugadores',['../class_cjt___jugadores.html#a3559862f2ddf964d670dc8a6ca7d1995',1,'Cjt_Jugadores']]],
  ['indice_5ftorneos_3',['indice_torneos',['../class_cjt___torneos.html#ae8ea5b4500669c662316ed25a23a38bf',1,'Cjt_Torneos']]]
];
