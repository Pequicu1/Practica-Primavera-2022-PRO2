var searchData=
[
  ['torneo_0',['Torneo',['../class_torneo.html#a7bf6d35a7ec8d0e13a0bed8deb8add3e',1,'Torneo']]]
];
