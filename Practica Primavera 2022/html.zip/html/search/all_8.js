var searchData=
[
  ['main_0',['main',['../program_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'program.cc']]],
  ['mas_5ftorneo_1',['mas_torneo',['../class_jugador.html#a2020987455711d7068f4ee600aab3d90',1,'Jugador']]],
  ['matriz_2',['Matriz',['../_cjt___torneos_8hh.html#a542f05eb5259f8e5499aa2e207ddffc3',1,'Cjt_Torneos.hh']]],
  ['modificar_5festadisticas_3',['modificar_estadisticas',['../class_cjt___jugadores.html#a4af2d82bb67b48f00c2712d1e9bc48d4',1,'Cjt_Jugadores']]],
  ['modificar_5fjuegos_4',['modificar_juegos',['../class_jugador.html#ab2911f6ac6a37fb9cc27499d0f379a6e',1,'Jugador']]],
  ['modificar_5fpartidos_5',['modificar_partidos',['../class_jugador.html#ac45437c4bd257d6bfb16e4a8ac3f1c3f',1,'Jugador']]],
  ['modificar_5fpuntos_6',['modificar_puntos',['../class_jugador.html#a9b73499771e156cc468c9a2ab4bd521f',1,'Jugador']]],
  ['modificar_5franking_7',['modificar_ranking',['../class_cjt___jugadores.html#a76148fa89c327c78999600b589f45d9f',1,'Cjt_Jugadores::modificar_ranking()'],['../class_jugador.html#af7b4bdbeae795163b53d5f0b9445b766',1,'Jugador::modificar_ranking(int n)']]],
  ['modificar_5fsets_8',['modificar_sets',['../class_jugador.html#aa12ab1bb66031833de8134c1262d624c',1,'Jugador']]]
];
