var searchData=
[
  ['partido_0',['Partido',['../struct_partido.html',1,'']]]
];
