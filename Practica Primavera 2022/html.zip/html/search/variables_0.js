var searchData=
[
  ['categoria_0',['categoria',['../class_torneo.html#ad9bec7ef311a416138abb99f3a487b3e',1,'Torneo']]],
  ['categorias_1',['categorias',['../class_cjt___torneos.html#ac022fbba080883fbc2763260b07853d5',1,'Cjt_Torneos']]],
  ['cuadro_2',['Cuadro',['../class_torneo.html#a0c3a5229ee80cd4f3363f90b335b37e8',1,'Torneo']]]
];
