var searchData=
[
  ['j1_0',['j1',['../struct_partido.html#a7796c4dcfed1668082ee8f08316a9015',1,'Partido']]],
  ['j2_1',['j2',['../struct_partido.html#ac804727c4e15b8898b9a8cc47882a3ff',1,'Partido']]],
  ['juegos_2',['juegos',['../class_jugador.html#ab8ea358b14201e7fad986174d0b04f16',1,'Jugador']]],
  ['jugador_3',['Jugador',['../class_jugador.html',1,'Jugador'],['../class_jugador.html#a232c46f75691af6210096e5972535d71',1,'Jugador::Jugador()']]],
  ['jugador_2ecc_4',['Jugador.cc',['../_jugador_8cc.html',1,'']]],
  ['jugador_2ehh_5',['Jugador.hh',['../_jugador_8hh.html',1,'']]]
];
