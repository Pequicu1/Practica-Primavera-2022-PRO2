var searchData=
[
  ['id_0',['id',['../class_jugador.html#aaeeacd8da7dd5926ca44073124b5fd71',1,'Jugador']]],
  ['identificador_1',['identificador',['../class_torneo.html#a8ef1999f3378e2b929bb042ddb98339d',1,'Torneo']]],
  ['imprimir_5fcuadro_2',['imprimir_cuadro',['../class_torneo.html#af344369c3f0ba575aa583412d03fed43',1,'Torneo']]],
  ['imprimir_5fjugadores_3',['imprimir_jugadores',['../class_cjt___jugadores.html#abf5308b5d4ff571486fbd02e81bc6413',1,'Cjt_Jugadores']]],
  ['imprimir_5fresultados_4',['imprimir_resultados',['../class_torneo.html#ab8fa41e367d8b2a71ee8274f9a92222d',1,'Torneo']]],
  ['imprimir_5ftorneos_5',['imprimir_torneos',['../class_cjt___torneos.html#a3479fb8622fbc711fed12727780e8141',1,'Cjt_Torneos']]],
  ['indice_5fjugadores_6',['indice_jugadores',['../class_cjt___jugadores.html#a3559862f2ddf964d670dc8a6ca7d1995',1,'Cjt_Jugadores']]],
  ['indice_5ftorneos_7',['indice_torneos',['../class_cjt___torneos.html#ae8ea5b4500669c662316ed25a23a38bf',1,'Cjt_Torneos']]],
  ['ini_5fjugadores_8',['ini_jugadores',['../class_cjt___jugadores.html#aa18a0cf28de1764a9179413b3731c45a',1,'Cjt_Jugadores']]],
  ['ini_5ftorneos_9',['ini_torneos',['../class_cjt___torneos.html#ab446783c7673ee52a5c69d35b23021d8',1,'Cjt_Torneos']]]
];
