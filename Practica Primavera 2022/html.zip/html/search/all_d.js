var searchData=
[
  ['sets_0',['sets',['../class_jugador.html#a0f820a9a62c75c9104ac759c48a2219b',1,'Jugador']]]
];
