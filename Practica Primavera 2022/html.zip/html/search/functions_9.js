var searchData=
[
  ['node_0',['Node',['../struct_bin_tree_1_1_node.html#af45885e303875c018e89fa5c8b96bde0',1,'BinTree::Node']]],
  ['numero_5fjugadores_1',['numero_jugadores',['../class_cjt___jugadores.html#ac0a8e34bec7aa6ef3ba33e6bb9eeaeb3',1,'Cjt_Jugadores']]],
  ['numero_5ftorneos_2',['numero_torneos',['../class_cjt___torneos.html#a0d18a560f7a69f89144c2eb2344d997e',1,'Cjt_Torneos']]]
];
