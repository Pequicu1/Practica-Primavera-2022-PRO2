var searchData=
[
  ['restar_5fpuntos_0',['restar_puntos',['../class_cjt___jugadores.html#afef4a536c490713226bacb027e98a5b2',1,'Cjt_Jugadores']]],
  ['right_1',['right',['../class_bin_tree.html#aff8e96651b27284c329667b5ad3e4d0b',1,'BinTree']]]
];
