var searchData=
[
  ['cjt_5fjugadores_0',['Cjt_Jugadores',['../class_cjt___jugadores.html',1,'']]],
  ['cjt_5ftorneos_1',['Cjt_Torneos',['../class_cjt___torneos.html',1,'']]]
];
