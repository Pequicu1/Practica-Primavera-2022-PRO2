var searchData=
[
  ['ganador_0',['ganador',['../class_torneo.html#a8fa674dd54b4be3543fd45d03573d7fa',1,'Torneo']]]
];
