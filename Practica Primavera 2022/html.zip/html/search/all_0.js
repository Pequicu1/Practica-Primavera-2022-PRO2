var searchData=
[
  ['actualiza_5fparticipantes_0',['actualiza_participantes',['../class_torneo.html#ad38ffc5a5b5c5c738b53c5add063ec7c',1,'Torneo']]],
  ['actualizar_5ftorneo_1',['actualizar_torneo',['../class_cjt___torneos.html#a67188435e5384ebf95ae8655006dd5fb',1,'Cjt_Torneos']]],
  ['anadir_5fjugador_2',['anadir_jugador',['../class_cjt___jugadores.html#a9a89be5d20688b55549d85fc4acdcba2',1,'Cjt_Jugadores']]],
  ['anadir_5ftorneo_3',['anadir_Torneo',['../class_cjt___torneos.html#a3111bef72d409401941fdb1f9173a1db',1,'Cjt_Torneos']]]
];
